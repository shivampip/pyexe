from .remote import Remote
from .local import Local
name = "pyexe"
